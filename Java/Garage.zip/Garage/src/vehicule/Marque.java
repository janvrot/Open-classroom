package vehicule;


public enum Marque {
	RENO,
	PIGEOT,
	TROEN
}

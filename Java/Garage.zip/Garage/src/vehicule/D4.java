package vehicule;

public class D4 extends Vehicule{
	
	public D4() {
		this.setMarque(Marque.TROEN);
		this.setNom("D4");
	}
}

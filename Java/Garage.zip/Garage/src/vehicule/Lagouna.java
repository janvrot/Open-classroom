package vehicule;

public class Lagouna extends Vehicule{
	
	public Lagouna() {
		this.setMarque(Marque.RENO);
		this.setNom("Lagouna");
	}
}

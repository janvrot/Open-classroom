package vehicule;

public class A300B extends Vehicule{
	
	public A300B() {
		this.setMarque(Marque.PIGEOT);
		this.setNom("A300B");
	}
}

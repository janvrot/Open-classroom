package option;

public interface Option {

	public Double getPrix();
	
	public String getNom();

}

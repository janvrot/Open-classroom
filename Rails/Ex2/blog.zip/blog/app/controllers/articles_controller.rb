class ArticlesController < ApplicationController
	def index
		@articles = Article.all
		@categories = Category.all
		@articles = Article.page(params[:page]).per(5)
	end
	def show
		@article = Article.find(params[:id])
		@categories = Category.all
		@comments = Article.find(params[:id]).comments
	end
	def create
		Article.create title: params[:title], content: params[:content], category_id: params[:category_id]
		redirect_to "/articles" 
	end
	def update
		@article = Article.find(params[:id])
		@categories = Category.all
		Article.find(params[:id]).update title: params[:title], content: params[:content], category_id: params[:category_id]
		if @article.update title: params[:title]
			redirect_to "/articles/#{params[:id]}"
		else
			render "show"
		end
	end
	def destroy
		Article.find(params[:id]).destroy
		redirect_to "/articles"
	end
end

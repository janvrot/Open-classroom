Rails.application.routes.draw do
  get 'articles/index'
  
  get 'articles' => 'articles#index'

  get 'articles/:id' => 'articles#show'

end
